#include "IRdWireable.h"

namespace rd
{
}