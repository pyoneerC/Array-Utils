﻿#pragma once

namespace RiderDebuggerSupport
{
    void SendLogToDebugger(const char* FormatStr, ...);
}
