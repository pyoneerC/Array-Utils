﻿#include "RiderDebuggerSupport.h"

#define LOCTEXT_NAMESPACE "FRiderDebuggerSupportModule"


void FRiderDebuggerSupportModule::StartupModule()
{
}

void FRiderDebuggerSupportModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FRiderDebuggerSupportModule, RiderDebuggerSupport)
