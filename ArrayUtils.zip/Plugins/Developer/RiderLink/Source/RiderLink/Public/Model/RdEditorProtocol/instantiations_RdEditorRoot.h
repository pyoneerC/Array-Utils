#ifndef INSTANTIATIONS_RDEDITORROOT_H
#define INSTANTIATIONS_RDEDITORROOT_H

#include "serialization/Polymorphic.h"


namespace rd {
}

#endif // INSTANTIATIONS_RDEDITORROOT_H
